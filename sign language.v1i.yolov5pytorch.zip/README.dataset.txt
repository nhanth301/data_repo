# sign language > 2024-04-12 1:25pm
https://universe.roboflow.com/nhanth301/sign-language-mz31h

Provided by a Roboflow user
License: CC BY 4.0

